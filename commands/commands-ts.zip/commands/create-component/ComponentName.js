import React from 'react';
import './style.scss';

const ComponentName = (props) => {
  return (
    <div className="container">
      <p>ComponentName</p>
    </div>
  );
};

export default ComponentName;
