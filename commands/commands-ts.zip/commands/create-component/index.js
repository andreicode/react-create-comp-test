import ComponentName from './ComponentName';

export default ComponentName;
